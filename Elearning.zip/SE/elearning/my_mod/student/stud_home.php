<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Student</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Student Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Courses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Grades</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Settings</a>
            </li>
          </ul>
          <button class="btn btn-outline-primary ms-auto">Logout</button>
        </div>
      </div>
    </nav>
  </header>

  <!-- Main content -->
  <main>
    <section class="py-5">
      <div class="container">
        <h1>Welcome!</h1>
        <p class="lead">Here's an overview of your courses</p>

        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Course 1</h2>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut mi eget erat egestas tincidunt. Praesent sed malesuada velit.</p>
                <a href="#" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Course 2</h2>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut mi eget erat egestas tincidunt. Praesent sed malesuada velit.</p>
                <a href="#" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Course 3</h2>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut mi eget erat egestas tincidunt. Praesent sed malesuada velit.</p>
                <a href="#" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

                    
                        </div>
                      </div>
                    </section>
                </main>
                <!-- Footer -->
                <footer class="bg-light py-3">
                  <div class="container text-center">
                    <p>&copy; 2023 Student Dashboard</p>
                  </div>
                </footer>
                <!-- JavaScript -->
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.min.js"></script>
              </body>
              </html>
              
              