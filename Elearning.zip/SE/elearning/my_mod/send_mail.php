<?php
if(isset($_POST['email'])) {
    // Set the recipient email address
    $to = $_POST['email'];

    // Set the subject line
    $subject = 'Message from ' . $_POST['name'];

    // Set the message body
    $message = $_POST['message'];

    // Set the headers
    $headers = "From: 21f2000664@ds.study.iitm.ac.in" . "\r\n" .
        "Reply-To: eyuvaraj.d@pec.edu" . "\r\n" .
        "X-Mailer: PHP/" . phpversion();

    // Send the email
    mail($to, $subject, $message, $headers);

    // Redirect the user to a confirmation page
    header('Location: confirmation.html');
    exit;
}
?>
