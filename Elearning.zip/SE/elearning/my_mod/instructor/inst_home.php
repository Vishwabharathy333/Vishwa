<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Course Instructor</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Course Instructor</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Courses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Students</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Settings</a>
            </li>
          </ul>
          <button class="btn btn-outline-primary ms-auto">Logout</button>
        </div>
      </div>
    </nav>
  </header>

  <!-- Main content -->
  <main>
    <section class="py-5">
      <div class="container">
        <h1>Welcome, John Doe!</h1>
        <p class="lead">Here's an overview of your courses and students:</p>

        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Course 1</h2>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut mi eget erat egestas tincidunt. Praesent sed malesuada velit.</p>
                <a href="#" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Course 2</h2>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut mi eget erat egestas tincidunt. Praesent sed malesuada velit.</p>
                <a href="#" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Course 3</h2>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut mi eget erat egestas tincidunt. Praesent sed malesuada velit.</p>
                <a href="#" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <h2 class="my-4">Recent Students</h2>
            <ul class="list-group">
                <li class="list-group-item">Student 1</li>
                <li class="list-group-item">Student 2</li>
                <li class="list-group-item">Student 3</li>
                <li class="list-group-item">Student 4</li>
              </ul>
            </div>
      
            <div class="col-md-6">
              <h2 class="my-4">Upcoming Courses</h2>
              <ul class="list-group">
                <li class="list-group-item">Course 4 - Starts on 01/01/2024</li>
                <li class="list-group-item">Course 5 - Starts on 02/01/2024</li>
                <li class="list-group-item">Course 6 - Starts on 03/01/2024</li>
                <li class="list-group-item">Course 7 - Starts on 04/01/2024</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </main>
    <!-- Footer -->
    <footer class="py-3 bg-light">
      <div class="container">
        <p class="text-center">&copy; 2023 Course Instructor</p>
      </div>
    </footer>
    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.min.js"></script>
  </body>
  </html>      