<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $message = $_POST["message"];

  // Validate form data
  $validData = true;
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) || empty($name) || empty($message)) {
    $validData = false;
  }

  if ($validData) {
    // Send email using PHPMailer
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->Username = 'dchitra160782r@gmail.com';
    $mail->Password = 'ArianaGrande';
    $mail->setFrom($email, $name);
    $mail->addAddress('wizard24e@gmail.com', 'Unknown');
    $mail->Subject = 'Your Notes';
    $mail->Body = "Name: $name\nEmail: $email\nMessage: $message";

    if ($mail->send()) {
        echo "Message sent!";
    } else {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
  } else {
    echo "Invalid form data";
  }
}
?>

<!-- HTML form for sending email -->
<div class="container">
  <section id="contact">
    <h1>Notes</h1>
    <div>
      <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="text" name="name" placeholder="Name" value="<?php echo $_POST['name'] ?? ''; ?>">
        <input type="email" name="email" placeholder="Email" value="<?php echo $_POST['email'] ?? ''; ?>">
        <textarea name="message" placeholder="Your Message"><?php echo $_POST['message'] ?? ''; ?></textarea>
        <button type="submit">SEND</button>
      </form>
    </div>
  </section>
</div>
