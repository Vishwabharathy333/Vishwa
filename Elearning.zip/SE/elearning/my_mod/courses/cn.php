<!DOCTYPE html>
<html>
<head>
	<title>Computer Networks</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<!-- Custom CSS -->
	<style>

		body {
			background-color: #f5f5f5;
			font-family: Arial, sans-serif;
		}
		h1 {
			margin-top: 20px;
			margin-bottom: 20px;
			text-align: center;
			font-weight: bold;
			color: #333;
		}
		.panel {
			margin-top: 40px;
			margin-bottom: 40px;
			border: 1px solid #ccc;
			border-radius: 10px;
			padding: 20px;
			box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
		}
		.topic {
			cursor: pointer;
			margin-bottom: 20px;
			padding: 10px;
			background-color: #fff;
			color: #333;
			border: 1px solid #ccc;
			border-radius: 10px;
			transition: all 0.3s ease-in-out;
		}
		.topic:hover {
			background-color: #333;
			color: #fff;
		}
		.active {
			background-color: #333;
			color: #fff;
		}
		.video {
			height: 100%;
			width: 100%;
		}

        .notes-container {
        width: 100%;
        padding: 20px;
        background-color: #f5f5f5;
        }

        .notes-container h2 {
        margin-top: 0;
        }

        .notes-container textarea {
        width: 100%;
        height: 100%;
        font-size: 16px;
        padding: 10px;
        border: none;
        resize: none;
        }

	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">E-Learning</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Hero Banner -->
    <section id="hero-banner">
        <div class="container">
            <div class="row">
				<div class="col-md-12">
					<h1>Computer Networks</h1>
				</div>
            </div>
        </div>
    </section>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 panel" id="topic-list">
				<h4>Topics</h4>
				<ul class="list-group">
					<li class="list-group-item" onclick="showVideo('lnU-Zw3NEEQ')">Introduction to Computer Networks</li>
					<li class="list-group-item" onclick="showVideo('29Qdz0FmvmQ')">Network Topologies</li>
					<li class="list-group-item" onclick="showVideo('b6f9vh3cd6w')">Network Protocols</li>
					<li class="list-group-item" onclick="showVideo('b6f9vh3cd6w')">Network Security</li>
				</ul>
			</div>
			<div class="col-md-8 panel" id="video-frame">
				<h4>Video</h4>
				<iframe width="100%" height="315" src="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</div>
	</div>

    <div class="notes-container">
	<form method="post" action="../send_mail.php">
          <h2>Notes</h2>
          <textarea id="notes" rows="10"></textarea>
		  <label for="email">Email:</label>
		  <input type="email" name="email" id="email"><br><br>
		  <input type="submit" value="Send">
	</form>
    </div>
      

	<!-- Bootstrap JS and jQuery -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
	<script>
		function showVideo(videoId) {
			document.getElementById('video-frame').innerHTML = '<iframe width="100%" height="315" src="https://www.youtube.com/embed/' + videoId + '" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
		}
    

        const video = document.getElementById("my-video");
        const notes = document.getElementById("notes");

        video.addEventListener("timeupdate", function() {
        // Save the current time and notes to localStorage
        localStorage.setItem("videoTime", video.currentTime);
        localStorage.setItem("notes", notes.value);
        });

        // Restore the video time and notes from localStorage
        video.currentTime = localStorage.getItem("videoTime") || 0;
        notes.value = localStorage.getItem("notes") || "";


	</script>
</body>
</html>
