<?php include '../assets/includes/header.php'; ?>
			
			<!-- DIRECTORY -->
			<div class="main-dir">
				<h1>Course Instructor Dashboard</h1>
			</div>
			<!-- END DIRECTORY -->

			<main>
				<section class="py-5">
				<div class="container">
					<h1>Welcome</h1>
					<p class="lead">Here's an overview of your courses and students:</p>

					<div class="row">
					<div class="col-md-4">
						<div class="card">
						<div class="card-body">
							<h2 class="card-title">Database Management System</h2>
							<p class="card-text">Learn the fundamentals of database management systems in this comprehensive course. No prior experience necessary!</p>
							<a href="../my_mod/courses/dbms.php" class="btn btn-primary">View Course</a>
						</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4">
							<div class="card">
							<div class="card-body">
								<h2 class="card-title">Computer Networks</h2>
								<p class="card-text">Explore the fundamentals of computer networks in this comprehensive course. No prior experience necessary!</p>
								<a href="../my_mod/courses/dbms.php" class="btn btn-primary">View Course</a>
							</div>
							</div>
						</div>
					</div>
				</div>
				</section>


    		</main>


<?php include '../assets/includes/footer.php'; ?>