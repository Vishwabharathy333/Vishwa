<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>About Us | E-Learning</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<!-- Custom CSS -->
	<style>
		.about-section {
			background-color: #f8f9fa;
			padding: 50px 0;
		}
		.about-heading {
			font-size: 36px;
			margin-bottom: 30px;
		}
		.about-content {
			font-size: 18px;
			line-height: 1.5;
			margin-bottom: 30px;
		}
		.about-img {
			margin-top: 30px;
			margin-bottom: 30px;
			border-radius: 50%;
			height: 300px;
			width: 300px;
			object-fit: cover;
		}
		.about-team {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			align-items: center;
			gap: 30px;
		}
		.about-member {
			background-color: #fff;
			padding: 30px;
			box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
			border-radius: 10px;
			text-align: center;
			flex: 1 1 300px;
			min-width: 300px;
			max-width: 400px;
		}
		.about-member img {
			height: 200px;
			width: 200px;
			border-radius: 50%;
			object-fit: cover;
			margin-bottom: 20px;
		}
		.about-member h3 {
			font-size: 24px;
			margin-bottom: 10px;
		}
		.about-member p {
			font-size: 18px;
			line-height: 1.5;
			margin-bottom: 20px;
		}
	</style>
</head>
<body>
	<!-- Header -->
	<header>
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container-fluid">
				<a class="navbar-brand" href="#">E-Learning</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNav">
					<ul class="navbar-nav">
						<li class="nav-item">
							<a class="nav-link" href="home.php">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="courses.php">Courses</a>
						</li>
						<li class="nav-item">
							<a class="nav-link active" href="about.php">About Us</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="contact.php">Contact Us</a>
						</li>
					</ul>
					<button class="btn btn-outline-primary ms-auto" onclick=location.href="login/index.php">Login</button>
				</div>
			</div>
		</nav>
	</header>
    <!-- Header End -->
    	<!-- About Section -->
<!-- Main Content -->
<main>
    <section class="about-section">
        <div class="container">
            <h2 class="about-heading">Our Story</h2>
            <p class="about-content">E-Learning was founded in 2023 with a mission to provide affordable and accessible education to everyone, everywhere. We believe that education is a fundamental right, and our platform is designed to help anyone learn anything, at any time.</p>
            <p class="about-content">Our team is made up of passionate educators and developers who are dedicated to creating the best learning experience possible. We work tirelessly to develop new courses, improve our platform, and support our community of learners.</p>
        </div>
    </section>
    <section class="team-section">
        <div class="container">
            <h2 class="about-heading">Meet Our Team</h2>
            <div class="about-team">
                <div class="about-member">
                    <img src="assets/img/avatar1.avif" alt="John Doe">
                    <h3>D Eyuvaraj</h3>
                    <p>Co-Founder</p>
                </div>
                <div class="about-member">
                    <img src="assets/img/avatar1.avif" alt="Jane Doe">
                    <h3>Vishwabarathi K</h3>
                    <p>Co-Founder</p>
                </div>
			</div>
		</div>
	</section>
</main>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p class="text-white mb-0">Copyright &copy; 
          <script>document.write(new Date().getFullYear())</script> E-Learning</p>
        </div>
        <div class="col-md-6">
          <ul class="list-inline mb-0">
            <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
            <li class="list-inline-item"><a href="#">Terms of Use</a></li>
            <li class="list-inline-item"><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!-- Scripts -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>