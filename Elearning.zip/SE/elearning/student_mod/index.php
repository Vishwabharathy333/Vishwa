<?php include '../assets/includes/header.php'; ?>
			
			<!-- DIRECTORY -->
			<div class="main-dir">
				<h1>Student Dashboard</h1>
			</div>
			<!-- END DIRECTORY -->
			
  <!-- Main content -->
  <main>

<!--
    <section class="py-5">
      <div class="container">
        <h1>Welcome!</h1>
        <p class="lead">Here's an overview of your courses</p>

        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Database Management System</h2>
                <a href="../my_mod/courses/dbms.php" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Computer Network</h2>
				<br>
                <a href="../my_mod/courses/cn.php" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Web Development Fundamentals</h2>
                <a href="../my_mod/courses/webdev.php" class="btn btn-primary">View Course</a>
              </div>
            </div>
          </div>

         </div>
-->
			
			<!-- DIRECTORY -->
			<div class="main-dir">
        <h1>Classes</h1>
			</div>
			<!-- END DIRECTORY -->
			
			<!-- CONTAINER -->
			<div class="main-container">
				<div class="inner-container">
					<div class="content-row">
						<div class="panel back-color-white">
							<div class="panel-content-norm">
								<table class="action-table" id="classTable">
									<tr>
										<th>Course</th>
										<th>Faculty</th>
										<th>Video Lectures</th>
									</tr>
									<?php $el->getClassesStudent1($user); ?>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END CONTAINER -->


    </section>
</main>

<?php include '../assets/includes/footer.php'; ?>