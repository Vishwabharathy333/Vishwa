<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - E-Learning</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">E-Learning</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="home.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Courses.php">Courses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About Us</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
          </ul>
          <button class="btn btn-outline-primary ms-auto" onclick=location.href="login/index.php">Login</button>
        </div>
      </div>
    </nav>
  </header>

  <!-- Main content -->
  <main>
    <section class="py-5">
      <div class="container">
        <h1>Contact Us</h1>
        <p class="lead">We're here to help! Please fill out the form below and we'll get back to you as soon as possible.</p>

        <div class="row">
          <div class="col-md-6">
            <form id="contact-form" method="post" action="send.php">
              <div class="form-group mb-3">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>

              <div class="form-group mb-3">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>

              <div class="form-group mb-3">
                <label for="subject">Subject</label>
                <input type="text" class="form-control" id="subject" name="subject" required>
              </div>

              <div class="form-group mb-3">
                <label for="message">Message</label>
                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
              </div>

              <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
          </div>

          <div class="col-md-6">
            <h2>Contact Information</h2>
            <p class="lead">Feel free to contact us using the information below:</p>

            <ul class="list-unstyled">
              <li><i class="bi bi-geo-alt-fill"></i>East coast Road, Pillaichavady <br>Pondicherry, India 605013</li>
              <li><i class="bi bi-envelope-fill"></i><a href="mailto:info@elearning.com">info@elearning.com</a></li>
              <li><i class="bi bi-phone-fill"></i><a href="tel:+1234567890">9988776633</a></li>
              </ul>
              </div>
              </div>
              </div>
              </section>
              
                </main>
  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p class="text-white mb-0">Copyright &copy; 
          <script>document.write(new Date().getFullYear())</script> E-Learning</p>
        </div>
        <div class="col-md-6">
          <ul class="list-inline mb-0">
            <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
            <li class="list-inline-item"><a href="#">Terms of Use</a></li>
            <li class="list-inline-item"><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!-- Scripts -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>