<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Introduction to Programming - E-Learning</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">E-Learning</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">Home</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="courses.php">Courses</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                    </ul>
                    <button class="btn btn-outline-primary ms-auto" onclick=location.href="login/index.php">Login</button>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main content -->
    <main>
        <section class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Introduction to Programming</h1>
                        <p class="lead">Learn the basics of programming in this introductory course. No prior experience necessary!</p>
                        <ul>
                            <li>Duration: 6 weeks</li>
                            <li>Time commitment: 3-4 hours per week</li>
                            <li>Price: ₹1999</li>
                        </ul>
                        <button class="btn btn-primary">View Course</button>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">About the Instructor</h5>
                                <p class="card-text">H Pandya is a senior software engineer with over 10 years of experience in the field. She has taught programming courses at the university level and is passionate about making programming accessible to everyone.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Database Management System</h1>
                        <p class="lead">Learn the fundamentals of database management systems in this comprehensive course. No prior experience necessary!</p>
                        <ul>
                            <li>Duration: 8 weeks</li>
                            <li>Time commitment: 4-5 hours per week</li>
                            <li>Price: ₹1499</li>
                        </ul>
                        <button class="btn btn-primary" onclick=location.href="my_mod/courses/dbms.php">View Course</button>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">About the Instructor</h5>
                                <p class="card-text">MS Dhoni is a seasoned database professional with over 15 years of experience in designing and managing databases for large-scale applications. He has taught database management courses at leading universities and is dedicated to sharing his expertise with aspiring database professionals.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Computer Network</h1>
                        <p class="lead">Explore the fundamentals of computer networks in this comprehensive course. No prior experience necessary!</p>
                        <ul>
                            <li>Duration: 10 weeks</li>
                            <li>Time commitment: 5-6 hours per week</li>
                            <li>Price: ₹1999</li>
                        </ul>
                        <button class="btn btn-primary" onclick=location.href="my_mod/courses/cn.php">View Course</button>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">About the Instructor</h5>
                                <p class="card-text">Sachin RT is a renowned expert in computer networking with over 20 years of experience in the field. She has authored several books on network architecture and has extensive hands-on experience in designing and implementing complex networks for organizations. Mary is committed to helping students grasp the intricacies of computer networks through her engaging teaching style.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Web Development Fundamentals</h1>
                        <p class="lead">Learn the fundamentals of web development in this comprehensive course. No prior experience necessary!</p>
                        <ul>
                            <li>Duration: 8 weeks</li>
                            <li>Time commitment: 4-5 hours per week</li>
                            <li>Price: ₹2999</li>
                        </ul>
                        <button class="btn btn-primary">View Course</button>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">About the Instructor</h5>
                                <p class="card-text">Virat Kholi is a seasoned web developer with over 15 years of experience in the field. He has worked on numerous web projects, ranging from small business websites to large e-commerce platforms. John is passionate about teaching web development and helping students build their skills in HTML, CSS, and JavaScript through practical projects and real-world examples.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </section>
    </main>
  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p class="text-white mb-0">Copyright &copy; 
          <script>document.write(new Date().getFullYear())</script> E-Learning</p>
        </div>
        <div class="col-md-6">
          <ul class="list-inline mb-0">
            <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
            <li class="list-inline-item"><a href="#">Terms of Use</a></li>
            <li class="list-inline-item"><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!-- Scripts -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>