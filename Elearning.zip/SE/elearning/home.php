<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>E-Learning Homepage</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">E-Learning</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="home.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="courses.php">Courses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
          </ul>
          <button class="btn btn-outline-primary ms-auto" onclick=location.href="login/index.php">Login</button>
        </div>
      </div>
    </nav>
  </header>

  <!-- Main content -->
  <main>
    <section class="py-5">
      <div class="container">
        <h1>Welcome to E-Learning</h1>
        <p class="lead">Our online courses cover a wide range of subjects, from coding to marketing and beyond. Whether you're looking to upskill for your current job or explore new career opportunities, we have the courses you need to succeed.</p>
        <a href="courses.php" class="btn btn-primary">Browse Courses</a>
      </div>
    </section>

    <section class="py-5 bg-light">
      <div class="container">
        <h2 class="mb-5">Featured Courses</h2>
        <div class="row row-cols-1 row-cols-md-2 g-4">
          <div class="col">
            <div class="card">
              <img src="assets/img/python.webp" class="card-img-top" alt="Course Image">
              <div class="card-body">
                <h3 class="card-title">Intro to Python</h3>
                <p class="card-text">This course covers the basics of Python programming, including data types, control structures, and functions. No prior programming experience required.</p>
                <a href="login/index.php" class="btn btn-primary">Enroll Now</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card">
              <img src="assets/img/webdev.png" class="card-img-top" alt="Course Image">
              <div class="card-body">
                <h3 class="card-title">Web Development Fundamentals</h3>
                <p class="card-text">This course covers the basics of web development, including HTML, CSS, and JavaScript. Perfect for beginners looking to get started with building websites.</p>
                <a href="login/index.php" class="btn btn-primary">Enroll Now</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p class="text-white mb-0">Copyright &copy; 
          <script>document.write(new Date().getFullYear())</script> E-Learning</p>
        </div>
        <div class="col-md-6">
          <ul class="list-inline mb-0">
            <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
            <li class="list-inline-item"><a href="#">Terms of Use</a></li>
            <li class="list-inline-item"><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!-- Scripts -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>